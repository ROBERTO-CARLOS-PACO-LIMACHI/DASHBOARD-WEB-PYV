/* async function WS(){
  const socket = new WebSocket("wss://cosmosblastingtools.com/ws/",
} */

export function home(req, res) {
  return res.render("home");
}
